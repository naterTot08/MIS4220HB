<!-- Declare Nurse Card Date -->
<?php
$nurseDate = new DateTime();
$nurseDate->setDate(2020, 11, 4);

$dueDate = new DateTime();
$dueDate->setDate(2020, 12, 12);


$totalDays = $nurseDate->diff($dueDate);
$today = new dateTime();
$daysFrom = $today->diff($nurseDate);
$daysTill = $today->diff($dueDate);

$percentComplete = ($daysFrom->format('%R%a')*-1) % $totalDays->format('%R%a');


?>